﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DiscordStructure
{
    public class Discord : IDiscord
    {
        private Dictionary<string, Message> messages = new Dictionary<string, Message>();
        private Dictionary<string, int> channelCounts = new Dictionary<string, int>();
        private List<Message> insertionOrder = new List<Message>();

        public int Count => messages.Count;

        public bool Contains(Message message) => messages.ContainsKey(message.Id);

        public void SendMessage(Message message, string channel)
        {
            if (messages.ContainsKey(message.Id)) return;
            message.Channel = channel;
            messages[message.Id] = message;
            insertionOrder.Add(message);

            if (!channelCounts.ContainsKey(channel))
            {
                channelCounts[channel] = 0;
            }

            channelCounts[channel]++;
        }

        public void DeleteMessage(string messageId)
        {
            if (!messages.ContainsKey(messageId)) throw new ArgumentException();
            var message = messages[messageId];
            messages.Remove(messageId);
            insertionOrder.Remove(message);
            channelCounts[message.Channel]--;
        }

        public Message GetMessage(string messageId)
        {
            if (!messages.ContainsKey(messageId)) throw new ArgumentException();
            return messages[messageId];
        }

        public void ReactToMessage(string messageId, string reaction)
        {
            if (!messages.ContainsKey(messageId)) throw new ArgumentException();
            messages[messageId].Reactions.Add(reaction);
        }

        public IEnumerable<Message> GetMessageInTimeRange(int lowerBound, int upperBound)
        {
            return insertionOrder
                .Where(m => m.Timestamp >= lowerBound && m.Timestamp <= upperBound)
                .OrderByDescending(m => channelCounts[m.Channel]);
        }

        public IEnumerable<Message> GetAllMessagesOrdered()
        {
            return insertionOrder
                .OrderByDescending(m => m.Reactions.Count)
                .ThenBy(m => m.Timestamp)
                .ThenBy(m => m.Content.Length);
        }
    }
}
